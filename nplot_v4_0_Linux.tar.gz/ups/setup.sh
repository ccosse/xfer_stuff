#!/bin/sh
nplot()
{
  $NPLOT_DIR/bin/nplot "$@"
}

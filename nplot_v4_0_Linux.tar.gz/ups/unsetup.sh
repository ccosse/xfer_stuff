#!/bin/sh
unset nplot
